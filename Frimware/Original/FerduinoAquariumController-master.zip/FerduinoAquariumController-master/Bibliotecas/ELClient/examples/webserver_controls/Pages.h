#ifndef PAGES_H
#define PAGES_H

void ledLoop();
void ledInit();

void userInit();

void voltageLoop();
void voltageInit();

#endif /* PAGES_H */


