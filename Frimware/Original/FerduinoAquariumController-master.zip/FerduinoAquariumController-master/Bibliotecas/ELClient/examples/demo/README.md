Simple demo
===========

**WARNING: this example has not been updated for EL-Client!**

